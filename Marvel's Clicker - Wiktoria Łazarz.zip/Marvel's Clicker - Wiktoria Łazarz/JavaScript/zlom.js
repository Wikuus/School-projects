var zlom = {

    pojemnosc: 100,
    cena: 2,
    ilosc: 0,
    cena_ulepszenia: 10,
    poziom_ulepszenia: 1,
    id_okna_ulepszenia: "cena_ulepszenia_mag_zlomu",

    ulepsz_magazyn: function()
    {
        if(kredyty.ilosc>=zlom.cena_ulepszenia)
        {
            switch(zlom.poziom_ulepszenia)
            {
                case 1:
                    zlom.poziom_ulepszenia=2;
                    zlom.pojemnosc=300;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=20;
                    wypisywanie();
                    break;
                case 2:
                    zlom.poziom_ulepszenia=3;
                    zlom.pojemnosc=700;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=40;
                    wypisywanie();
                    break;
                case 3:
                    zlom.poziom_ulepszenia=4;
                    zlom.pojemnosc=1500;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=100;
                    wypisywanie();
                    break;
                case 4:
                    zlom.poziom_ulepszenia=5;
                    zlom.pojemnosc=3500;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=250;
                    wypisywanie();
                    break;
                case 5:
                    zlom.poziom_ulepszenia=6;
                    zlom.pojemnosc=5000;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=400;
                    wypisywanie();
                    break;
                case 6:
                    zlom.poziom_ulepszenia=7;
                    zlom.pojemnosc=8000;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia=700;
                    wypisywanie();
                    break;
                case 7:
                    zlom.poziom_ulepszenia=8;
                    zlom.pojemnosc=12000;
                    kredyty.ilosc-=zlom.cena_ulepszenia;
                    zlom.cena_ulepszenia="Maks.<br>poziom";
                    wypisywanie();
                    break;

                    
            }

        }
        else
        {
            chwilowy_kolor(2,zlom.id_okna_ulepszenia)
        }
        
    },

    sprzedaj: function()
    {
        if(zlom.ilosc>0)
        {
            zlom.ilosc-=1;
            kredyty.ilosc+=zlom.cena;
            kolor_zlomu();
            wypisywanie();
        }
    },
    
    sprzedaj_wszystko: function()
    {
        if(zlom.ilosc>0)
        {
            kredyty.ilosc+=(zlom.ilosc*zlom.cena);
            zlom.ilosc=0;
            kolor_zlomu();
            wypisywanie();
        }

    }
}