function czasowka()
{
    auto_zbieranie=setInterval(function(){generowanie()},1000);
}

function czy_sa_czesci()
{
    var losuj=parseInt(Math.random()*100);
    if(legion.poziom_ulepszenia==1)
    {
        if(losuj<=5)
        {
            czesci.ilosc+=legion.ilosc*jest_oko;
        }
    }
    if(legion.poziom_ulepszenia==2)
    {
        if(losuj<=10)
        {
            czesci.ilosc+=legion.ilosc*jest_oko;
        }
    }
    if(legion.poziom_ulepszenia==3)
    {
        if(losuj<=25)
        {
            czesci.ilosc+=legion.ilosc*jest_oko;
        }
    }
    if(legion.poziom_ulepszenia==4)
    {
        if(losuj<=40)
        {
            czesci.ilosc+=legion.ilosc*jest_oko;
        }
    }
    if(legion.poziom_ulepszenia==5)
    {
        if(losuj<=70)
        {
            czesci.ilosc+=legion.ilosc*jest_oko;
        }
    }
    

}

function generowanie()
{
    if(prad.wymagany=="tak")
    {
        kolor_pradu();
        if(prad.ilosc>=legion.ilosc*2)
        {
            document.getElementById("prad_iron_legion").style.backgroundColor="rgb(73, 73, 73)";
            prad.ilosc-=legion.ilosc*2;
            zlom.ilosc+=legion.ilosc*jest_oko;
            kolor_zlomu();
            czy_sa_czesci();
            kolor_czesci()
            prad.ilosc+=1;
            kolor_pradu();
            wypisywanie();

        }
        else
        {
            document.getElementById("prad_iron_legion").style.backgroundColor="red";
            console.log("Za mało prądu w Iron Legion");
            prad.ilosc+=1;
            kolor_pradu();
            wypisywanie();
        }

    }
    else
    {
            document.getElementById("prad_iron_legion").style.backgroundColor="rgb(73, 73, 73)";
            zlom.ilosc+=legion.ilosc*jest_oko;
            kolor_zlomu();
            czy_sa_czesci();
            kolor_czesci()
            wypisywanie();

    }
}