var zaawansowany = {

    pojemnosc: 10,
    cena: 10000,
    ilosc: 0,
    cena_ulepszenia: 1000,
    poziom_ulepszenia: 1,

    wymagany_uklad: 20,
    wymagany_czesci: 100,
    wymagany_prad: 100,
    id_okna_ulepszenia: "cena_ulepszenia_mag_zaawans",
    id_okna_tworzenia: "zaawansowany_tworzenie_materialy",
    

    ulepsz_magazyn: function()
    {
        if(kredyty.ilosc>=zaawansowany.cena_ulepszenia)
        {
            switch(zaawansowany.poziom_ulepszenia)
            {
                case 1:
                    zaawansowany.poziom_ulepszenia=2;
                    zaawansowany.pojemnosc=100;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=1500;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 2:
                    zaawansowany.poziom_ulepszenia=3; 
                    zaawansowany.pojemnosc=300;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=2200;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 3:
                    zaawansowany.poziom_ulepszenia=4;
                    zaawansowany.pojemnosc=500;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=2800;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 4:
                    zaawansowany.poziom_ulepszenia=5;
                    zaawansowany.pojemnosc=900;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=3500;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 5:
                    zaawansowany.poziom_ulepszenia=6;
                    zaawansowany.pojemnosc=1400;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=5000;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
                case 6:
                    zaawansowany.poziom_ulepszenia=7;
                    zaawansowany.pojemnosc=1800;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia=8000;
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;
 
                case 7:
                    zaawansowany.poziom_ulepszenia=8;
                    zaawansowany.pojemnosc=2500;
                    kredyty.ilosc-=zaawansowany.cena_ulepszenia;
                    zaawansowany.cena_ulepszenia="Maks.<br>poziom";
                    wypisywanie();
                    kolor_zaawansowanych();
                    break;

                    
            }

        }
        else
        {
            chwilowy_kolor(2,zaawansowany.id_okna_ulepszenia)
        }
        
    },

    sprzedaj: function()
    {
        if(zaawansowany.ilosc>0)
        {
            zaawansowany.ilosc-=1;
            kredyty.ilosc+=zaawansowany.cena;
            kolor_zaawansowanych();
            wypisywanie();
        }

    },

    stworz: function()
    {
        if(prad.wymagany=="tak")
        {
        if(uklad.ilosc>=zaawansowany.wymagany_uklad && prad.ilosc>=zaawansowany.wymagany_prad && czesci.ilosc>=zaawansowany.wymagany_czesci && zaawansowany.ilosc<zaawansowany.pojemnosc)
        {
            prad.ilosc-=zaawansowany.wymagany_prad;
            uklad.ilosc-=zaawansowany.wymagany_uklad;
            czesci.ilosc-=zaawansowany.wymagany_czesci;
            zaawansowany.ilosc+=1;
            kolor_ukladow();
            kolor_czesci();
            kolor_zaawansowanych();
            wypisywanie();
            

        }
        else
        {
            chwilowy_kolor(2,zaawansowany.id_okna_tworzenia)
        }
        }
        else
        {
            if(uklad.ilosc>=zaawansowany.wymagany_uklad && czesci.ilosc>=zaawansowany.wymagany_czesci && zaawansowany.ilosc<zaawansowany.pojemnosc)
            {
            uklad.ilosc-=zaawansowany.wymagany_uklad;
            czesci.ilosc-=zaawansowany.wymagany_czesci;
            zaawansowany.ilosc+=1;
            kolor_ukladow();
            kolor_czesci();
            kolor_zaawansowanych();
            wypisywanie();
            

            }   
        else
            {
            chwilowy_kolor(2,zaawansowany.id_okna_tworzenia)
            }

        }

    },

    sprzedaj_wszystko: function()
    {
        if(zaawansowany.ilosc>0)
        {
            kredyty.ilosc+=(zaawansowany.ilosc*zaawansowany.cena);
            zaawansowany.ilosc=0;
            kolor_zaawansowanych();
            wypisywanie();
        }

    }
}