function stark_odblokuj()
        {
            if(kredyty.ilosc>=50000)
            {
                kredyty.ilosc-=50000;
                wypisywanie();
                document.getElementById("stark_do_usuniecia").remove();

                var tr1_1=document.createElement("tr");
                tr1_1.id="tr1-1";
                document.getElementById("tabela_stark").appendChild(tr1_1);
                    var td1_1=document.createElement("td");
                    td1_1.setAttribute("class","tabelki_napisy");
                    td1_1.setAttribute("colspan","2");
                    td1_1.innerHTML="Surowiec";
                    document.getElementById("tr1-1").appendChild(td1_1);

                    var td2_1=document.createElement("td");
                    td2_1.setAttribute("class","tabelki_napisy");
                    td2_1.innerHTML="Potrzebne materiały";
                    document.getElementById("tr1-1").appendChild(td2_1);

                    var td3_1=document.createElement("td");
                    td3_1.setAttribute("class","tabelki_napisy");
                    td3_1.innerHTML="Stwórz";
                    document.getElementById("tr1-1").appendChild(td3_1);

                var tr2_1=document.createElement("tr");
                tr2_1.id="tr2-1";
                document.getElementById("tabela_stark").appendChild(tr2_1);
                    var td4_1=document.createElement("td");
                    td4_1.id="td4-1";
                    document.getElementById("tr2-1").appendChild(td4_1);
                    var img1_1=document.createElement("img");
                    img1_1.setAttribute("class","surowce_zdj");
                    img1_1.setAttribute("alt","Części");
                    img1_1.setAttribute("src","./Wyglad/czesci_el.png");
                    document.getElementById("td4-1").appendChild(img1_1);

                    var td5_1=document.createElement("td");
                    td5_1.innerHTML="Części elektroniczne";
                    document.getElementById("tr2-1").appendChild(td5_1);

                    var td6_1=document.createElement("td");
                    td6_1.id="czesci_tworzenie_materialy";
                    td6_1.innerHTML="4 x Złom<br>10 x Prąd";
                    document.getElementById("tr2-1").appendChild(td6_1);

                    var td7_1=document.createElement("td");
                    td7_1.id="td7-1";
                    document.getElementById("tr2-1").appendChild(td7_1);
                    var guzik1_1=document.createElement("button");
                    guzik1_1.setAttribute("type","button");
                    guzik1_1.setAttribute("onclick","czesci.stworz()");
                    guzik1_1.id="guzik1-1";
                    document.getElementById("td7-1").appendChild(guzik1_1);
                    var stworz_zdj=document.createElement("img");
                    stworz_zdj.setAttribute("class","surowce_zdj");
                    stworz_zdj.setAttribute("alt","Stwórz");
                    stworz_zdj.setAttribute("src","./Wyglad/tworzenie.png");
                    document.getElementById("guzik1-1").appendChild(stworz_zdj);

                var tr3_1=document.createElement("tr");
                tr3_1.id="tr3-1";
                document.getElementById("tabela_stark").appendChild(tr3_1);
                    var td8_1=document.createElement("td");
                    td8_1.id="td8-1";
                    document.getElementById("tr3-1").appendChild(td8_1);
                    var img2_1=document.createElement("img");
                    img2_1.setAttribute("class","surowce_zdj");
                    img2_1.setAttribute("alt","Układ scalony");
                    img2_1.setAttribute("src","./Wyglad/uklad_scal.png");
                    document.getElementById("td8-1").appendChild(img2_1);

                    var td9_1=document.createElement("td");
                    td9_1.innerHTML="Układ scalony";
                    document.getElementById("tr3-1").appendChild(td9_1);

                    var td10_1=document.createElement("td");
                    td10_1.id="uklad_tworzenie_materialy";
                    td10_1.innerHTML="30 x Części elektroniczne<br>10 x Złom<br>25 x Prąd";
                    document.getElementById("tr3-1").appendChild(td10_1);

                    var td11_1=document.createElement("td");
                    td11_1.id="td11-1";
                    document.getElementById("tr3-1").appendChild(td11_1);
                    var guzik2_1=document.createElement("button");
                    guzik2_1.setAttribute("type","button");
                    guzik2_1.setAttribute("onclick","uklad.stworz()");
                    guzik2_1.id="guzik2-1";
                    document.getElementById("td11-1").appendChild(guzik2_1);
                    var stworz_zdj2=document.createElement("img");
                    stworz_zdj2.setAttribute("class","surowce_zdj");
                    stworz_zdj2.setAttribute("alt","Stwórz");
                    stworz_zdj2.setAttribute("src","./Wyglad/tworzenie.png");
                    document.getElementById("guzik2-1").appendChild(stworz_zdj2);
            }
            else
            {
                chwilowy_kolor(2,"stark_blokuj_wymagania");
            }
        }


function wakanda_odblokuj()
        {
            if(kredyty.ilosc>=100000)
            {
                kredyty.ilosc-=100000;
                wypisywanie();
                document.getElementById("wakanda_do_usuniecia").remove();

                var tr1_2=document.createElement("tr");
                tr1_2.id="tr1-2";
                document.getElementById("tabela_wakanda").appendChild(tr1_2);
                    var td1_2=document.createElement("td");
                    td1_2.setAttribute("class","tabelki_napisy");
                    td1_2.setAttribute("colspan","2");
                    td1_2.innerHTML="Surowiec";
                    document.getElementById("tr1-2").appendChild(td1_2);

                    var td2_2=document.createElement("td");
                    td2_2.setAttribute("class","tabelki_napisy");
                    td2_2.innerHTML="Potrzebne materiały";
                    document.getElementById("tr1-2").appendChild(td2_2);

                    var td3_2=document.createElement("td");
                    td3_2.setAttribute("class","tabelki_napisy");
                    td3_2.innerHTML="Stwórz";
                    document.getElementById("tr1-2").appendChild(td3_2);

                var tr2_2=document.createElement("tr");
                tr2_2.id="tr2-2";
                document.getElementById("tabela_wakanda").appendChild(tr2_2);
                    var td4_2=document.createElement("td");
                    td4_2.id="td4-2";
                    document.getElementById("tr2-2").appendChild(td4_2);
                    var img1_2=document.createElement("img");
                    img1_2.setAttribute("class","surowce_zdj");
                    img1_2.setAttribute("alt","Zaawansowany układ scalony");
                    img1_2.setAttribute("src","./Wyglad/zaaw_uk_scal.png");
                    document.getElementById("td4-2").appendChild(img1_2);

                    var td5_2=document.createElement("td");
                    td5_2.innerHTML="Zaawansowany<br>układ scalony";
                    document.getElementById("tr2-2").appendChild(td5_2);

                    var td6_2=document.createElement("td");
                    td6_2.id="zaawansowany_tworzenie_materialy";
                    td6_2.innerHTML="20 x Układ scalony<br>100 x Części elektroniczne<br>100 x Prąd";
                    document.getElementById("tr2-2").appendChild(td6_2);

                    var td7_2=document.createElement("td");
                    td7_2.id="td7-2";
                    document.getElementById("tr2-2").appendChild(td7_2);
                    var guzik1_2=document.createElement("button");
                    guzik1_2.setAttribute("type","button");
                    guzik1_2.setAttribute("onclick","zaawansowany.stworz()");
                    guzik1_2.id="guzik1-2";
                    document.getElementById("td7-2").appendChild(guzik1_2);
                    var stworz_zdj3=document.createElement("img");
                    stworz_zdj3.setAttribute("class","surowce_zdj");
                    stworz_zdj3.setAttribute("alt","Stwórz");
                    stworz_zdj3.setAttribute("src","./Wyglad/tworzenie.png");
                    document.getElementById("guzik1-2").appendChild(stworz_zdj3);

                var tr3_2=document.createElement("tr");
                tr3_2.id="tr3-2";
                document.getElementById("tabela_wakanda").appendChild(tr3_2);
                    var td8_2=document.createElement("td");
                    td8_2.id="td8-2";
                    document.getElementById("tr3-2").appendChild(td8_2);
                    var img2_2=document.createElement("img");
                    img2_2.setAttribute("class","surowce_zdj");
                    img2_2.setAttribute("alt","Stabilizator soniczny");
                    img2_2.setAttribute("src","./Wyglad/satabilizator_ikonka.png");
                    document.getElementById("td8-2").appendChild(img2_2);

                    var td9_2=document.createElement("td");
                    td9_2.innerHTML="Stabilizator soniczny";
                    document.getElementById("tr3-2").appendChild(td9_2);

                    var td10_2=document.createElement("td");
                    td10_2.id="stabilizator_tworzenie_materialy";
                    td10_2.innerHTML="100 x Zaawansowany układ<br>scalony<br>400 000 x Kredyty";
                    document.getElementById("tr3-2").appendChild(td10_2);

                    var td11_2=document.createElement("td");
                    td11_2.id="td11-2";
                    document.getElementById("tr3-2").appendChild(td11_2);
                    var guzik2_2=document.createElement("button");
                    guzik2_2.setAttribute("type","button");
                    guzik2_2.setAttribute("onclick","stabilizator.stworz()");
                    guzik2_2.id="guzik2-2";
                    document.getElementById("td11-2").appendChild(guzik2_2);
                    var stworz_zdj4=document.createElement("img");
                    stworz_zdj4.setAttribute("class","surowce_zdj");
                    stworz_zdj4.setAttribute("alt","Stwórz");
                    stworz_zdj4.setAttribute("src","./Wyglad/tworzenie.png");
                    document.getElementById("guzik2-2").appendChild(stworz_zdj4);
            }
            else
            {
                chwilowy_kolor(2,"wakanda_blokuj_wymagania")
            }
        }