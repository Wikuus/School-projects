var silnik_mp3=new Audio('\Dzwieki/silnik.mp3');
            silnik_mp3.volume=0.2;
            silnik_mp3.loop=true;


var startowa_mp4=new Audio('\Dzwieki/piosenka_start.mp3');
            startowa_mp4.volume=0.4;
            startowa_mp4.loop=true;

var lvl1_muzyka=new Audio('\Dzwieki/poziomy1.mp3');
            lvl1_muzyka.volume=0.4;
            lvl1_muzyka.loop=true;

var lvl2_muzyka=new Audio('\Dzwieki/poziom2.mp3');
            lvl2_muzyka.volume=0.4;
            lvl2_muzyka.loop=true;

var lvl3_muzyka=new Audio('\Dzwieki/poziom3.mp3');
            lvl3_muzyka.volume=0.4;
            lvl3_muzyka.loop=true;

var lvl4_muzyka=new Audio('\Dzwieki/poziom4.mp3');
            lvl4_muzyka.volume=0.4;
            lvl4_muzyka.loop=true;

var lvl5_muzyka=new Audio('\Dzwieki/poziom5.mp3');
            lvl5_muzyka.volume=0.4;
            lvl5_muzyka.loop=true;

var lvl6_muzyka=new Audio('\Dzwieki/poziom6.mp3');
            lvl6_muzyka.volume=0.4;
            lvl6_muzyka.loop=true;

var lvl7_muzyka=new Audio('\Dzwieki/poziom7.mp3');
            lvl7_muzyka.volume=0.4;
            lvl7_muzyka.loop=true;

var lvl8_muzyka=new Audio('\Dzwieki/poziom8.mp3');
            lvl8_muzyka.volume=0.4;
            lvl8_muzyka.loop=true;

var napisy_muzyka=new Audio('\Dzwieki/napisy.mp3');
            napisy_muzyka.volume=0.4;
            napisy_muzyka.loop=true;
