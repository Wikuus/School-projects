function czy_trafilo_przeciwnika(strzalID,przeciwnikID)
{
    var IDprzeciwnika=document.getElementById(przeciwnikID);

    var strzalX=strzalID.offsetLeft;
    var przeciwnikX=IDprzeciwnika.offsetLeft;
    var strzalY=strzalID.offsetTop;
    var przeciwnikY=IDprzeciwnika.offsetTop;
    var przeciwnikSzer=IDprzeciwnika.offsetWidth
    if(przeciwnikID=="boss") 
    {
        var przeciwnikWys=IDprzeciwnika.offsetHeight-40;
    }
    else
    {
        var przeciwnikWys=IDprzeciwnika.offsetHeight;

    }
    
    var przeciwnikZycie=IDprzeciwnika.alt;
    
    if(strzalX>przeciwnikX-10 && strzalX<przeciwnikX+przeciwnikSzer && strzalY>przeciwnikY && strzalY<przeciwnikY+przeciwnikWys-13)
    {
        IDprzeciwnika.alt-=1;
        if(przeciwnikZycie<=0)
        {
            IDprzeciwnika.src="./Wyglad/Statki/wybuch_statku.gif";
            
            var wybuch_wav=new Audio('\Dzwieki/wybuch.wav');
            wybuch_wav.volume=0.1;
            wybuch_wav.play();

            setTimeout(function(){
                IDprzeciwnika.style.display="none";
                IDprzeciwnika.src="./Wyglad/Statki/wrogi_statek1.png";
            },420)
            
            
        }
        return true;
    }

    return false;
}

function czy_trafilo_strzal(IDstrzalu)
{
    var strzal_X=IDstrzalu.offsetLeft;
    var strzal_Y=IDstrzalu.offsetTop;
    for(var kolejny=0;kolejny<101;kolejny++)
    {
        if(document.getElementById("kula"+kolejny)!=null)
        {
            var kula_wroga_X=document.getElementById("kula"+kolejny).offsetLeft;
            var kula_wroga_Y=document.getElementById("kula"+kolejny).offsetTop;
            var kula_wroga_wys=document.getElementById("kula"+kolejny).offsetHeight;
            var kula_wroga_szer=document.getElementById("kula"+kolejny).offsetWidth;
            if(strzal_X>kula_wroga_X-18 && strzal_X<kula_wroga_X+kula_wroga_szer+5 &&
                strzal_Y<kula_wroga_Y+kula_wroga_wys && strzal_Y>kula_wroga_Y)
                {
                    document.getElementById("kula"+kolejny).remove();
                    return true;
                }
        }
    }
    return false;
}

function trafila_gracza(kula_id)
{
    var kulaY=kula_id.offsetTop+kula_id.offsetHeight;
    var kulaX=kula_id.offsetLeft;
    var graczY=document.getElementById("statek").offsetTop;
    var graczX=document.getElementById("statek").offsetLeft;
    var graczWys=document.getElementById("statek").offsetHeight;
    var graczSzer=document.getElementById("statek").offsetWidth;

    if(kulaY>graczY+15 && kulaY<graczY+graczWys &&
       kulaX>graczX-10 && kulaX<graczX+graczSzer-7)
       {
            return true;
       }
    else
       return false;

}