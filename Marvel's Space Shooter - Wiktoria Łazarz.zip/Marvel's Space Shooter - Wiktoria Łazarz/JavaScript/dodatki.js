var nr_serca=1;
function spawn_serc()
{
    spawnowanie_serc=setInterval(function(){
        kontrola_serc=setInterval(function(){
            if(document.getElementById("okno_przegranej").style.display=="") 
            {clearInterval(spawnowanie_serc);
                clearInterval(kontrola_serc);
            }

        },100)
        var serce_x=parseInt(Math.random()*680);
        if(nr_serca>100) nr_serca=1;
        nr_serca++;
        var tlo_poziomow=document.getElementById("tlo_poziomow");
        var serce=document.createElement("img");
            serce.id="serce_nowe"+nr_serca;
            serce.style.top="0px";
            serce.style.left=serce_x+"px";
            serce.className="lecace_serca";
            serce.draggable=false;
            serce.src="./Wyglad/Statki/serce.png";
            tlo_poziomow.appendChild(serce);
            lecenie_serca("serce_nowe"+nr_serca);
    },10000)
}
function lecenie_serca(id_serca)
{
    var serceID=document.getElementById(id_serca)
    var serce_y=0;
    var lecenie_serc=setInterval(function(){
        if(trafila_gracza(serceID) || document.getElementById("okno_przegranej").style.display=="")
    {
        clearInterval(lecenie_serc);
        serceID.remove();
        if(gracz.zycie<3) gracz.zycie+=1;
    }
    else
    {
        if(serce_y<470)
        {
            serce_y+=7;
            serceID.style.top=serce_y+"px";
        }
        else
        {
            clearInterval(lecenie_serc);
            serceID.remove();
        }
    }
    },50)
}

document.getElementById("wybor_statku_tekst").addEventListener("click",zmiana_statku)

function zmiana_statku()
{
    if(document.getElementById("wybor_statku").alt==1)
    {
        document.getElementById("wybor_statku").alt=2;
        document.getElementById("wybor_statku").src="./Wyglad/Statki/statek2.png";
        document.getElementById("statek").src="./Wyglad/Statki/statek2.png";
        wybrany_statek="./Wyglad/Statki/statek2.png";
        return true;
    }
    else if(document.getElementById("wybor_statku").alt==2)
    {
        document.getElementById("wybor_statku").alt=3;
        document.getElementById("wybor_statku").src="./Wyglad/Statki/statek3.png";
        document.getElementById("statek").src="./Wyglad/Statki/statek3.png";
        wybrany_statek="./Wyglad/Statki/statek3.png";
        return true;
    }
    else if(document.getElementById("wybor_statku").alt==3)
    {
        document.getElementById("wybor_statku").alt=1;
        document.getElementById("wybor_statku").src="./Wyglad/Statki/statek.png";
        document.getElementById("statek").src="./Wyglad/Statki/statek.png";
        wybrany_statek="./Wyglad/Statki/statek.png";
        return true;
    }

}