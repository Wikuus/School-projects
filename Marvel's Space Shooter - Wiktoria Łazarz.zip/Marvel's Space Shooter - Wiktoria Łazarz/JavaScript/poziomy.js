function wlaczanie_poziomu()
{
    startowa_mp4.pause();
    document.getElementById("przeciwnik1").style.top="20px";
    document.getElementById("przeciwnik2").style.top="20px";
    document.getElementById("przeciwnik3").style.top="20px";
    document.getElementById("przeciwnik4").style.top="20px";
    document.getElementById("przeciwnik5").style.top="20px";
    
    document.getElementById("menu_poziomow").removeEventListener("click", zanikanie_start)
    var przezroczystosc1=1;
    var przezroczystosc2=0;
    document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
    document.getElementById("ekran_ladowania").style.display="unset";
    var zanikanie=setInterval(function() {
        if(przezroczystosc1>0)
        {
            przezroczystosc1-=0.05;
            przezroczystosc2+=0.05;
            document.getElementById("menu_poziomow").style.opacity=przezroczystosc1;
            document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
        }
        else
        {
            document.getElementById("menu_poziomow").style.display="none";
            setTimeout(function(){
                silnik_mp3.play();
                var przezroczystosc1=1;
                var przezroczystosc2=0;
                document.getElementById("tlo_poziomow").style.opacity=przezroczystosc2;
                document.getElementById("tlo_poziomow").style.display="";
                var zanikanie=setInterval(function() {
                    if(przezroczystosc1>0)
                    {
                        przezroczystosc1-=0.05;
                        przezroczystosc2+=0.05;
                        document.getElementById("ekran_ladowania").style.opacity=przezroczystosc1;
                        document.getElementById("tlo_poziomow").style.opacity=przezroczystosc2;
                        
                    }
                    else
                    {
                        document.getElementById("ekran_ladowania").style.display="none";
                        
                        clearInterval(zanikanie);
                    }
                },40);
            },300)
            clearInterval(zanikanie);
        }
    },40);
}




function poziom1()
{
    wlaczanie_poziomu();
    pokaz("statek");
    ukryj("serce1");
    ukryj("serce2");
    ukryj("serce3");
    pojaw_przeciwnika("przeciwnik1","wrogi_statek1.png",5);
    pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
    pojaw_przeciwnika("przeciwnik5","wrogi_statek1.png",5);
    gracz.obecny_poziom=1;

    pokaz("dymek_dialogu");
    pokaz("gif_dialog_starlord");
    pokaz("dymek_tekst");
    pokaz("dymek_guzik_dalej");
    document.getElementById("dymek_tekst").innerHTML="Czy ktoś ma pomysł, dlaczego banda Suwerennych nas atakuje?";

    document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog2);
}
    function lv1_dialog2()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog2);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_drax");
        document.getElementById("dymek_tekst").innerHTML="Może chcą spowrotem ogniwa, które ukradł Rocket.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog3);
    }
    function lv1_dialog3()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog3);
        ukryj("gif_dialog_drax");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Miałeś nikomu nie mówić ty szara maso!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog4);
    }
    function lv1_dialog4()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog4);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_drax");
        document.getElementById("dymek_tekst").innerHTML="Faktycznie, rocket nic nie ukradł. Nie wiem, o co może im chodzić.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog5);
    }
    function lv1_dialog5()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog5);
        ukryj("gif_dialog_drax");
        pokaz("gif_dialog_gamora");
        document.getElementById("dymek_tekst").innerHTML="I po co ci to było Rocket? Teraz będą nas ścigać po całej galaktyce. Zajmij się tym teraz, szczurze.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog6);
    }
    function lv1_dialog6()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog6);
        ukryj("gif_dialog_gamora");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Już się nimi zajmę, zabijanie ludzi jest fajne!!! Tylko zapuść jakąś fajną muze Quill!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv1_dialog7);
    }
    function lv1_dialog7()
    {
        gracz.zycie=1;
        gracz.obecny_poziom=1;
        
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv1_dialog7);
        
        ukryj("dymek_dialogu");
        ukryj("gif_dialog_rocket");
        ukryj("dymek_tekst");
        ukryj("dymek_guzik_dalej");
        lvl1_muzyka.play();
        rozpoczecie_poziomu();
        strzelanie_wroga("przeciwnik1",40);
        strzelanie_wroga("przeciwnik3",40);
        strzelanie_wroga("przeciwnik5",40);
        
        czy_zabici=setInterval(function(){
            if(document.getElementById("przeciwnik1").style.display=="none" &&
                document.getElementById("przeciwnik2").style.display=="none" &&
                document.getElementById("przeciwnik3").style.display=="none" &&
                document.getElementById("przeciwnik4").style.display=="none" &&
                document.getElementById("przeciwnik5").style.display=="none")
            {
                clearInterval(czy_zabici);
                setTimeout(function(){
                pojaw_przeciwnika_animacja("przeciwnik1","wrogi_statek2.png",10);
                pojaw_przeciwnika_animacja("przeciwnik3","wrogi_statek2.png",10);
                pojaw_przeciwnika_animacja("przeciwnik5","wrogi_statek2.png",10);
                strzelanie_wroga("przeciwnik1",25);
                strzelanie_wroga("przeciwnik1",30);
                strzelanie_wroga("przeciwnik3",25);
                strzelanie_wroga("przeciwnik3",30);
                strzelanie_wroga("przeciwnik5",25);
                strzelanie_wroga("przeciwnik5",30);
                setTimeout(function(){
                    pojaw_przeciwnika_animacja("przeciwnik2","wrogi_statek1.png",5);
                    pojaw_przeciwnika_animacja("przeciwnik4","wrogi_statek1.png",5);
                    strzelanie_wroga("przeciwnik2",40);
                    strzelanie_wroga("przeciwnik4",40);
                    czy_zabici2=setInterval(lv1_dalej,600);

                },800);
            },500)
            }
        },600);
        

    }

    function lv1_dalej()
    {
        if(document.getElementById("przeciwnik1").style.display=="none" &&
                document.getElementById("przeciwnik2").style.display=="none" &&
                document.getElementById("przeciwnik3").style.display=="none" &&
                document.getElementById("przeciwnik4").style.display=="none" &&
                document.getElementById("przeciwnik5").style.display=="none")
            {
                clearInterval(czy_zabici2);
                setTimeout(function(){
                pojaw_przeciwnika_animacja("przeciwnik1","wrogi_statek2.png",10);
                pojaw_przeciwnika_animacja("przeciwnik3","wrogi_statek2.png",10);
                pojaw_przeciwnika_animacja("przeciwnik5","wrogi_statek2.png",10);
                strzelanie_wroga("przeciwnik1",25);
                strzelanie_wroga("przeciwnik1",30);
                strzelanie_wroga("przeciwnik3",25);
                strzelanie_wroga("przeciwnik3",30);
                strzelanie_wroga("przeciwnik5",25);
                strzelanie_wroga("przeciwnik5",30);
                setTimeout(function(){
                    pojaw_przeciwnika_animacja("przeciwnik2","wrogi_statek1.png",5);
                    pojaw_przeciwnika_animacja("przeciwnik4","wrogi_statek1.png",5);
                    strzelanie_wroga("przeciwnik2",40);
                    strzelanie_wroga("przeciwnik4",40);
                    czy_zabici3=setInterval(lv1_dalej2,600);

                },800);
            },500)
            }
    }
    function lv1_dalej2()
    {
        if(document.getElementById("przeciwnik1").style.display=="none" &&
                document.getElementById("przeciwnik2").style.display=="none" &&
                document.getElementById("przeciwnik3").style.display=="none" &&
                document.getElementById("przeciwnik4").style.display=="none" &&
                document.getElementById("przeciwnik5").style.display=="none")
            {
                clearInterval(czy_zabici3);
                if(zaliczone_poziomy.lvl1=="nie")
                {
                gracz.poziom=2;
                }
                zaliczone_poziomy.lvl1="tak";
                statek_odlot();
                setTimeout(function(){
                    lvl1_muzyka.pause();
                },100)
            }
        
    }