    function poziom6()
    {
        wlaczanie_poziomu();
        pokaz("statek");
        pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
        gracz.obecny_poziom=6;
        gracz.zycie=3;
        sprawdzaj_zycie();
    
        pokaz("dymek_dialogu");
        pokaz("gif_dialog_gamora");
        pokaz("dymek_tekst");
        pokaz("dymek_guzik_dalej");
        document.getElementById("dymek_tekst").innerHTML="I jak ci idzie z szukaniem tego statku Peter?";
    
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog2);
    }
        function lv6_dialog2()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog2);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="No zajmie to ciut dłużej niż myślałem...";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog3);
        }
        function lv6_dialog3()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog3);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="Jak zwykle, tak to jest powierzyć jakieś zadanie Quillowi!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog4);
        }
        function lv6_dialog4()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog4);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Bo ty oczywiście zrobiłbyś to szybciej tak? To ty szukaj!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog5);
        }
        function lv6_dialog5()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog5);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="Ty zacząłeś szukać, to już ty szukaj. Ja mam ważniejsze rzeczy do robienia.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog6);
        }
        function lv6_dialog6()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog6);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Jakież to rzeczy gryzoniu są ważniejsze od statku Królowej?";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog7);
        }
        function lv6_dialog7()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog7);
            ukryj("gif_dialog_drax");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="Ważniejsze jest zestrzelenia tych osłów przed nami, zanim oni zrobią to pierwsi, ty łysa pało!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv6_dialog8);
        }
        
        function lv6_dialog8()
        {
            gracz.zycie=3;
            gracz.obecny_poziom=6;
            
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv6_dialog8);
            
            ukryj("dymek_dialogu");
            ukryj("gif_dialog_rocket");
            ukryj("dymek_tekst");
            ukryj("dymek_guzik_dalej");
            lvl6_muzyka.play();
            rozpoczecie_poziomu();
    
            strzelanie_wroga("przeciwnik1",25);
            strzelanie_wroga("przeciwnik1",30);

            strzelanie_wroga("przeciwnik2",40);
            strzelanie_wroga("przeciwnik3",25);
            strzelanie_wroga("przeciwnik3",30);
            
            strzelanie_wroga("przeciwnik4",40);
            strzelanie_wroga("przeciwnik5",25);
            strzelanie_wroga("przeciwnik5",30);
            spawn_serc();
    
            var lvl6_czy_dalej=0;
    
            lvl6_czy_zabici=setInterval(function(){
            if(lvl6_czy_dalej<=6)
            {
                if(document.getElementById("przeciwnik1").style.display=="none" &&
                    document.getElementById("przeciwnik2").style.display=="none" &&
                    document.getElementById("przeciwnik3").style.display=="none" &&
                    document.getElementById("przeciwnik4").style.display=="none" &&
                    document.getElementById("przeciwnik5").style.display=="none")
                {
                    lvl6_czy_dalej++;
                    if(lvl6_czy_dalej<=6)
                    setTimeout(function(){
                    generuj_wroga("przeciwnik1");
                    generuj_wroga("przeciwnik2");
                    generuj_wroga("przeciwnik3");
                    generuj_wroga("przeciwnik4");
                    generuj_wroga("przeciwnik5");
                    },500)
    
                }
            }
            else
            {
                clearInterval(lvl6_czy_zabici);
    
                if(zaliczone_poziomy.lvl6=="nie")
                    {
                    gracz.poziom=7;
                    }
                    zaliczone_poziomy.lvl6="tak";
                    statek_odlot();
                    setTimeout(function(){
                        lvl6_muzyka.pause();
                    },100)
    
            }
            
            },600);
            
        }

    function poziom7()
    {
        wlaczanie_poziomu();
        pokaz("statek");
        pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
        pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
        gracz.obecny_poziom=7;
        gracz.zycie=3;
        sprawdzaj_zycie();
    
        pokaz("dymek_dialogu");
        pokaz("gif_dialog_gamora");
        pokaz("dymek_tekst");
        pokaz("dymek_guzik_dalej");
        document.getElementById("dymek_tekst").innerHTML="Peter znalazłeś wkońcu ten statek głównodowodzący?";
    
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog2);
    }
        function lv7_dialog2()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog2);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Tak, przelecimy przez parę oddziałów i będziemy mieli prostą drogę do niego.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog3);
        }
        function lv7_dialog3()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog3);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Spisałeś się Peterze Quillu, prawię dogoniłeś mnie z poziomem inteligencji.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog4);
        }
        function lv7_dialog4()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog4);
            ukryj("gif_dialog_drax");
            pokaz("gif_dialog_gamora");
            document.getElementById("dymek_tekst").innerHTML="Bo twój poziom jest faktycznie wysoki...";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog5);
        }
        function lv7_dialog5()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog5);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Cieszę się, że się ze mną zgadzasz morderczyni.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog6);
        }
        function lv7_dialog6()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog6);
            ukryj("gif_dialog_drax");
            pokaz("gif_dialog_gamora");
            document.getElementById("dymek_tekst").innerHTML="Cieszę się, że tak myślisz. Możemy wkońcu ruszać?";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog7);
        }
        function lv7_dialog7()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog7);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Już się robi!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv7_dialog8);
        }
        
        function lv7_dialog8()
        {
            gracz.zycie=3;
            gracz.obecny_poziom=7;
            
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv7_dialog8);
            
            ukryj("dymek_dialogu");
            ukryj("gif_dialog_starlord");
            ukryj("dymek_tekst");
            ukryj("dymek_guzik_dalej");
            lvl7_muzyka.play();
            rozpoczecie_poziomu();
    
            strzelanie_wroga("przeciwnik1",25);
            strzelanie_wroga("przeciwnik1",30);

            strzelanie_wroga("przeciwnik2",25);
            strzelanie_wroga("przeciwnik2",30);
            strzelanie_wroga("przeciwnik3",25);
            strzelanie_wroga("przeciwnik3",30);
            
            strzelanie_wroga("przeciwnik4",25);
            strzelanie_wroga("przeciwnik4",30);
            strzelanie_wroga("przeciwnik5",25);
            strzelanie_wroga("przeciwnik5",30);
            spawn_serc();
    
            var lvl7_czy_dalej=0;
    
            lvl7_czy_zabici=setInterval(function(){
            if(lvl7_czy_dalej<=6)
            {
                if(document.getElementById("przeciwnik1").style.display=="none" &&
                    document.getElementById("przeciwnik2").style.display=="none" &&
                    document.getElementById("przeciwnik3").style.display=="none" &&
                    document.getElementById("przeciwnik4").style.display=="none" &&
                    document.getElementById("przeciwnik5").style.display=="none")
                {
                    lvl7_czy_dalej++;
                    if(lvl7_czy_dalej<=6)
                    setTimeout(function(){
                    generuj_wroga("przeciwnik1");
                    generuj_wroga("przeciwnik2");
                    generuj_wroga("przeciwnik3");
                    generuj_wroga("przeciwnik4");
                    generuj_wroga("przeciwnik5");
                    },500)
    
                }
            }
            else
            {
                clearInterval(lvl7_czy_zabici);
    
                if(zaliczone_poziomy.lvl7=="nie")
                    {
                    gracz.poziom=8;
                    }
                    zaliczone_poziomy.lvl7="tak";
                    statek_odlot();
                    setTimeout(function(){
                        lvl7_muzyka.pause();
                    },100)
    
            }
            
            },600);
            
        }