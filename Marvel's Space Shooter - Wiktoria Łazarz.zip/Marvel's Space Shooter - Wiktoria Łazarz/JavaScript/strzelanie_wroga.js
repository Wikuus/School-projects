var kula_wroga=1;

function strzelanie_wroga(id_wroga,szybkosc)
{
    var atak=setInterval(function(){
        if(document.getElementById(id_wroga).style.display!="none")
        {
            if(kula_wroga<100)
            {
                    var wrogi_strzal=document.getElementById(id_wroga);
                    var wrogi_strzal_x=parseInt(wrogi_strzal.offsetLeft+(wrogi_strzal.offsetWidth/2)-10)
                    if(id_wroga=="boss")
                    {
                        var wrogi_strzal_y=parseInt(wrogi_strzal.offsetTop+wrogi_strzal.offsetHeight-40);
                    }
                    else
                    {
                        var wrogi_strzal_y=parseInt(wrogi_strzal.offsetTop+wrogi_strzal.offsetHeight-5);
                    }
                    var tlo_poziomow=document.getElementById("tlo_poziomow");
                    var nowy_strzal=document.createElement("img");
                        nowy_strzal.id="kula"+kula_wroga;
                        nowy_strzal.style.top=wrogi_strzal_y+"px";
                        nowy_strzal.style.left=wrogi_strzal_x+"px";
                        nowy_strzal.className="pociski";
                        nowy_strzal.draggable=false;
                        nowy_strzal.src="./Wyglad/Statki/strzal2.png";
                        tlo_poziomow.appendChild(nowy_strzal);

                    lecenie_kuli_wroga(document.getElementById(nowy_strzal.id),szybkosc)

                    kula_wroga++;

            }
            else
            {
                kula_wroga=1;
            }
            if(document.getElementById(id_wroga)==null)
            {
                clearInterval(atak);
            }





        }
        else
        {
            clearInterval(atak);
        }
    },1200)
    var kontrola=setInterval(function(){
        if(document.getElementById(id_wroga).style.display=="none")
        {
            clearInterval(atak);
            clearInterval(kontrola);
        }

    },100)
}

function lecenie_kuli_wroga(id_kuli,szybki)
{
    var kula_y=id_kuli.offsetTop;
    var lot=setInterval(function(){
    if(trafila_gracza(id_kuli))
    {
        id_kuli.src="./Wyglad/Statki/wybuch.gif";

        var trafienie_mp3=new Audio('\Dzwieki/trafienie.mp3');
        trafienie_mp3.volume=0.1;
        trafienie_mp3.play();

        clearInterval(lot);
        setTimeout(function(){
            id_kuli.remove();
        },220)
        gracz.zycie-=1;
        if(gracz.zycie<=0)
        {
            var wybuch_wav=new Audio('\Dzwieki/wybuch.wav');
            wybuch_wav.volume=0.1;
            wybuch_wav.play();
            silnik_mp3.pause();
            document.getElementById("tlo_poziomow").removeEventListener("mousemove",ruszanie_statkiem);
            document.getElementById("tlo_poziomow").removeEventListener("click",strzelanie);
            document.getElementById("statek").src="\Wyglad/Statki/wybuch_statku.gif";
            setTimeout(function(){
                przegrana();
            },800)
            
        }

    }
    else
    {
        if(kula_y<480)
        {
            kula_y+=7;
            id_kuli.style.top=kula_y+"px";
        }
        else
        {
            clearInterval(lot);
            id_kuli.remove();
        }
    }
    },szybki)
}

