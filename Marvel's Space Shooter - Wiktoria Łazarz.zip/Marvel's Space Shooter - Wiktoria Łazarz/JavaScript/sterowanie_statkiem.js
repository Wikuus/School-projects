document.getElementById("tlo_poziomow").addEventListener("mousemove",ruszanie_statkiem);

document.onselectstart = function(){return false;};

function ruszanie_statkiem(event)
{
    var pozycja_statek=document.getElementById("statek");
    var statek_x=event.offsetX;
    if(statek_x>60 && statek_x<640)
    {
        pozycja_statek.style.left=statek_x-60+"px";

    }
}

document.getElementById("tlo_poziomow").addEventListener("click",strzelanie);

var nr_pocisku=1;

function strzelanie()
{
    
    strzal_x=parseInt(document.getElementById("statek").style.left)+50+"px";
    var tlo_poziomow=document.getElementById("tlo_poziomow");
    var strzal=document.createElement("img");
        strzal.id="pocisk"+nr_pocisku;
        strzal.className="pociski";
        strzal.src="./Wyglad/Statki/strzal.png";
        strzal.style.top="405px";
        strzal.style.left=strzal_x;
        strzal.draggable=false;
        tlo_poziomow.appendChild(strzal);

        strzal_lecenie(document.getElementById(strzal.id))
        nr_pocisku++;

    //dzwiek
    var strzal_mp3=new Audio('\Dzwieki/strzal.mp3');
    strzal_mp3.volume=0.05;
    strzal_mp3.play();
}

function strzal_lecenie(id_strzalu)
{
    var strzal_id=id_strzalu;
    var strzal_y=405;
    var lecenie=setInterval(function(){
        if(strzal_y>=4)
        {
            if(!czy_trafilo_przeciwnika(strzal_id,"przeciwnik1") &&
               !czy_trafilo_przeciwnika(strzal_id,"przeciwnik2") &&
               !czy_trafilo_przeciwnika(strzal_id,"przeciwnik3") &&
               !czy_trafilo_przeciwnika(strzal_id,"przeciwnik4") &&
               !czy_trafilo_przeciwnika(strzal_id,"przeciwnik5") &&
               !czy_trafilo_przeciwnika(strzal_id,"boss") &&
               !czy_trafilo_strzal(strzal_id))
            {
                strzal_y-=10;
                strzal_id.style.top=strzal_y+"px";
            }
            else
            {
                clearInterval(lecenie);
                strzal_id.src="./Wyglad/Statki/wybuch.gif";

                var trafienie_mp3=new Audio('\Dzwieki/trafienie.mp3');
                trafienie_mp3.volume=0.1;
                trafienie_mp3.play();

                setTimeout(function(){
                    strzal_id.remove();
                },420)
                
            }

        }
        else
        {
            clearInterval(lecenie);
            strzal_id.remove();
        }
    },40);
}
