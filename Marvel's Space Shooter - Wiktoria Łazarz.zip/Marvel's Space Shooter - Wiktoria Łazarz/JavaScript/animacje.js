function pokaz(id_elementu)
{
    document.getElementById(id_elementu).style.display="";
}

function ukryj(id_elementu)
{
    document.getElementById(id_elementu).style.display="none";
}

function ustaw_przeciwnika(id_przeciwnika,zdj_przeciwnika,ilosc_zycia)
{
    document.getElementById(id_przeciwnika).src="./Wyglad/Statki/"+zdj_przeciwnika;
    document.getElementById(id_przeciwnika).alt=ilosc_zycia;
}

function pojaw_przeciwnika(id_przeciwnika,zdj_przeciwnika,ilosc_zycia)
{
    document.getElementById(id_przeciwnika).src="./Wyglad/Statki/"+zdj_przeciwnika;
    document.getElementById(id_przeciwnika).alt=ilosc_zycia;
    document.getElementById(id_przeciwnika).style.display="";
}

function pojaw_przeciwnika_animacja(id_przeciwnika,zdj_przeciwnika,ilosc_zycia)
{
    document.getElementById(id_przeciwnika).src="./Wyglad/Statki/"+zdj_przeciwnika;
    var wys=0;
    document.getElementById(id_przeciwnika).style.top=wys+"px";
    document.getElementById(id_przeciwnika).alt=ilosc_zycia;
    document.getElementById(id_przeciwnika).style.display="";
    var przylot=setInterval(function(){
        if(document.getElementById(id_przeciwnika).offsetTop<20)
        {
            wys+=2.5;
            document.getElementById(id_przeciwnika).style.top=wys+"px";
        }
        else
        {
            clearInterval(przylot);
        }
    },50)
}

var wybrany_statek="\Wyglad/Statki/statek.png";

function reset_statku()
{
    var gracz=document.getElementById("statek");
    gracz.src=wybrany_statek;
    gracz.style.left="270px";
    gracz.style.top="430px";
}

function statek_odlot()
{
    document.getElementById("tlo_poziomow").removeEventListener("mousemove",ruszanie_statkiem);
    document.getElementById("tlo_poziomow").removeEventListener("click",strzelanie);
    var statekY=document.getElementById("statek").offsetTop;
    odlot=setInterval(function(){
        if(document.getElementById("statek").offsetTop<5)
        {
            clearInterval(odlot)
            wlacz_ekran_ladowania();
            ukryj("statek");
            reset_statku();
        }
        else
        {
        statekY-=10;
        document.getElementById("statek").style.top=statekY+"px";
        }
    },20)
    
    for(var i=0;i<100;i++)
            {
            if(typeof(przesuwanie)!="undefined") clearInterval(przesuwanie);
            if(typeof(przesun)!="undefined") clearInterval(przesun);
            if(typeof( lecenie_serc)!="undefined") clearInterval( lecenie_serc);
            if(typeof(sprawdz_serca)!="undefined") clearInterval(sprawdz_serca);
            if(typeof(spawnowanie_serc)!="undefined") clearInterval(spawnowanie_serc);
            if(typeof(kontrola_bossa)!="undefined") clearInterval(kontrola_bossa);
            if(typeof(ruszanie_bossa)!="undefined") clearInterval(ruszanie_bossa);
            if(typeof(sprawdzanie_zycia_bossa)!="undefined") clearInterval(sprawdzanie_zycia_bossa);
            }
}